export const bchainProto = require('./blockchain.proto');
export const accProto = require('./account.proto');
export const clientProto = require('./client.proto');
export const networkProto = require('./network.proto');
